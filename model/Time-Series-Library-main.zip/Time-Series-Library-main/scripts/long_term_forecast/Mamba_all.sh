./scripts/long_term_forecast/ECL_script/Mamba.sh
./scripts/long_term_forecast/Traffic_script/Mamba.sh
./scripts/long_term_forecast/Exchange_script/Mamba.sh
./scripts/long_term_forecast/Weather_script/Mamba.sh
